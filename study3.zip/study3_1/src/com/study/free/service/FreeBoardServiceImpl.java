package com.study.free.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.study.common.util.MybatisSqlSessionFactory;
import com.study.exception.BizNotEffectedException;
import com.study.exception.BizNotFoundException;
import com.study.exception.BizPasswordNotMatchedException;
import com.study.free.dao.IFreeBoardDao;
import com.study.free.vo.FreeBoardSearchVO;
import com.study.free.vo.FreeBoardVO;

public class FreeBoardServiceImpl implements IFreeBoardService{
	SqlSessionFactory sqlSessionFactory = MybatisSqlSessionFactory.getSqlSessionFactory();
	
	@Override
	public List<FreeBoardVO> getBoardList(FreeBoardSearchVO searchVO) {
		try (SqlSession session = sqlSessionFactory.openSession(true)) {
			IFreeBoardDao freeBoardDao = session.getMapper(IFreeBoardDao.class);
			int totalRowCount = freeBoardDao.getTotalRowCount(searchVO);
			searchVO.setTotalRowCount(totalRowCount);
			searchVO.pageSetting();
			return freeBoardDao.getBoardList(searchVO);
		}
	}

	@Override
	public FreeBoardVO getBoard(int boNo) throws BizNotFoundException {
		try (SqlSession session = sqlSessionFactory.openSession(true)) {
			IFreeBoardDao freeBoardDao = session.getMapper(IFreeBoardDao.class);
			FreeBoardVO freeBoard = freeBoardDao.getBoard(boNo);
			if (freeBoard == null)
				throw new BizNotFoundException();
			return freeBoard;
		}
	}

	
	@Override
	public void increaseHit(int boNo) throws BizNotEffectedException {
		try (SqlSession session = sqlSessionFactory.openSession(true)) {
			IFreeBoardDao freeBoardDao = session.getMapper(IFreeBoardDao.class);
			int cnt = freeBoardDao.increaseHit(boNo);
			if (cnt == 0)
				throw new BizNotEffectedException();
		}
	}

	@Override
	public void modifyBoard(FreeBoardVO freeBoard)
			throws BizNotFoundException, BizPasswordNotMatchedException, BizNotEffectedException {
		try (SqlSession session = sqlSessionFactory.openSession(true)) {
			IFreeBoardDao freeBoardDao = session.getMapper(IFreeBoardDao.class);
			FreeBoardVO vo = freeBoardDao.getBoard(freeBoard.getBoNo());

			if (vo == null)
				throw new BizNotFoundException();
			if (!vo.getBoPass().equals(freeBoard.getBoPass()))
				throw new BizPasswordNotMatchedException();
			int resultCnt = freeBoardDao.updateBoard(freeBoard);
			if (resultCnt == 0)
				throw new BizNotEffectedException();
		}
	}
	
	@Override
	public void removeBoard(FreeBoardVO freeBoard)
			throws BizNotFoundException, BizPasswordNotMatchedException, BizNotEffectedException {
		try (SqlSession session = sqlSessionFactory.openSession(true)) {
			IFreeBoardDao freeBoardDao = session.getMapper(IFreeBoardDao.class);
			FreeBoardVO vo = freeBoardDao.getBoard(freeBoard.getBoNo());
			if (vo == null)
				throw new BizNotFoundException();
			if (!vo.getBoPass().equals(freeBoard.getBoPass()))
				throw new BizPasswordNotMatchedException();
			int resultCnt = freeBoardDao.deleteBoard(freeBoard);
			if (resultCnt == 0)
				throw new BizNotEffectedException();
		}
	}
	
	@Override
	public void registBoard(FreeBoardVO freeBoard) throws BizNotEffectedException {
		try (SqlSession session = sqlSessionFactory.openSession(true)) {
			IFreeBoardDao freeBoardDao = session.getMapper(IFreeBoardDao.class);
			int resultCnt = freeBoardDao.insertBoard(freeBoard);
			if (resultCnt == 0)
				throw new BizNotEffectedException();
		}
	}

}
