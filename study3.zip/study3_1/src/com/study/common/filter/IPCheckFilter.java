package com.study.common.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class IPCheckFilter implements Filter{
	private Map<String, Boolean> denyIpMap = new HashMap<String, Boolean>();
	
	
	// 필터 처음 실행시에만 한번 실행
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// 192.168.1.24
		denyIpMap.put("192.168.1.30", false);
		denyIpMap.put("192.168.1.35", false);
		denyIpMap.put("192.168.1.38", false);
		
	}
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)request;
		if(denyIpMap.get(req.getRemoteAddr())!=null) {
			HttpServletResponse resp = (HttpServletResponse)response;
			resp.setContentType("text/html; charset = utf-8");
			PrintWriter out = resp.getWriter();
			out.print("<html><body><h1>당신은 접근할수없는사람입니다</h1></body></html>");
		}else {
			chain.doFilter(request, response);
		}
	}
	
}
