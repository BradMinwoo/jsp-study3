
public class Main {

	public static void main(String[] args) {
		char a = 'A'; // 65
		char b = 'B';	// 66
		System.out.println((a+1)==b);

	}

}
