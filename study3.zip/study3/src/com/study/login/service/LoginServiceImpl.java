package com.study.login.service;

import com.study.login.vo.UserVO;
import com.study.member.dao.IMemberDao;
import com.study.member.dao.MemberDaoOracle;
import com.study.member.vo.MemberVO;

public class LoginServiceImpl implements ILoginService{
	IMemberDao memberDao = new MemberDaoOracle();
	
	@Override
	public UserVO getUser(String memId) {
		MemberVO member= memberDao.getMember(memId);
		if(member != null) {
			UserVO user = new UserVO();
			user.setUserId(memId);
			user.setUserName(member.getMemName());
			user.setUserPass(member.getMemPass());
			user.setUserRole("MEMBER");
			return user;
		}else {
			return null;
		}
		
	}
}
