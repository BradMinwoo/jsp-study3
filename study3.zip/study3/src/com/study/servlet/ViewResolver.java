package com.study.servlet;

public interface ViewResolver {
	public static String prefix = "/WEB-INF/views/";
	public static String suffix = ".jsp";
}
