package com.study.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.study.free.web.FreeList;

public class DispatcherServlet extends HttpServlet{
	private RequestMappingHandlerMapping handlerMapping;
	
	@Override
	public void init() throws ServletException {
		String uriPropertiesLocation = "/WEB-INF/classes/config/uri_handlermapping.properties";
		try {
			handlerMapping = new RequestMappingHandlerMapping(getServletContext(), uriPropertiesLocation);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String uri = req.getRequestURI();
		uri = uri.substring(req.getContextPath().length());
		Handler handler = handlerMapping.getHandler(uri);	// /free/freeList.wow   freeabcd.wow
		if(handler == null) {
			resp.sendError(404);
		}else {
			try {
				String viewPage = handler.process(req, resp);
				// /WEB-INF/views/~~~.jsp => free/freeList
				if(viewPage.startsWith("redirect:")) {
					resp.sendRedirect(viewPage.substring("redirect:".length()));
				}else {
					viewPage = ViewResolver.prefix+viewPage+ViewResolver.suffix;
					RequestDispatcher rd =req.getRequestDispatcher(viewPage);
					rd.forward(req, resp);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
